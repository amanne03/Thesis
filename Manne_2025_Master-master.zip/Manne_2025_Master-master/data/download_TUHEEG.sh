#! /bin/bash

# Download the current version of the TUH EEG corpus
# https://isip.piconepress.com/projects/nedc/html/tuh_eeg/
# Currently version of EEG dataset is v2.0.1 (Today is October 4th 2024)

url=www.isip.piconepress.com
user=nedc-tuh-eeg 
pass=RLYF8ZhBMZwNnsYA8FsP
#GROUP=/Users/benjamincauchi/Downloads/TRASH
outdir=${GROUP}/Datasets/TUH_EEG
# rm -rf ${outdir}
# mkdir -p ${outdir}

datasets=(
    TEST 
    tuh_eeg
    tuh_eeg_abnormal 
    tuh_eeg_artifact 
    tuh_eeg_epilepsy 
    tuh_eeg_events 
    tuh_eeg_seizure 
    tuh_eeg_slowing 
    tuh_eeg_software 
    tutorials 
)

for set in "${datasets[@]}"; do
    sshpass -p ${pass} rsync -auxvL --delete ${user}@${url}:data/tuh_eeg/${set} ${outdir}
done

