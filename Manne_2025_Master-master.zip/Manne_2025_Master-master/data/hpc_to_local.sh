#! /bin/bash

# Copy part of both datasets (2 patients per dataset) from the hpc to the local machine

src_dir=/nfs/group/agamt/Datasets/


tueg_dir=TUH_EEG/tuh_eeg/v2.0.1/edf
tueg_patients=(
    000
    001
)
mkdir -p ${tueg_dir}
for patient in "${tueg_patients[@]}"; do
    scp -r rosa:${src_dir}/${tueg_dir}/${patient} ${tueg_dir}
done


icare_dir=2023_Physionet_Official/i-care/2.0/training
icare_patients=(
    0284
    0286
)
mkdir -p ${icare_dir}
for patient in "${icare_patients[@]}"; do
    scp -r rosa:${src_dir}/${icare_dir}/${patient} ${icare_dir}
done

