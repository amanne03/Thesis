Template for thesis writing.
Scripts to generate the figures are in makeFigures
Instructions and tips are provided as comments in the tex code and in 
the resulting main.pdf

You can change your title, name, supervisors...
in the file utilities/thesisInfo.sty

Note on compiling your document:

## On Mac using TexPad:
press: CMD + T (this will use the main.tpbuild script included in the directory)

## On Windows using TexMaker:

1) To do once, configure TexMaker:
Options->Settings Files->Reset Settings

Then Open TexMaker Preferences, in the Menu:
Options -> Configure Texmaker
Click on tab Commands (on the left) and next to PdfLateX replace the line:
"pdflatex" -synctex=1 -interaction=nonstopmode %.tex
by
"pdflatex" -synctex=1 -interaction=nonstopmode -shell-escape %.tex

Click on tab Quick Build and select:
PdfLaTex + Bib(la)tex + PdfLaTex (x2) + View Pdf

Click OK to apply your changes

2) To do for each compilation:
Click on Arrow next to Quick Build or press F1