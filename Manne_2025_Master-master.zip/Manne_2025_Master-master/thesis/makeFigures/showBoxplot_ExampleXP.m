clear all, close all, clc
warning off
% Make sure we know what is on our Matlab path:
restoredefaultpath
% Add utilities functions from the XPs directory
addpath(genpath(fullfile(pwd,'..','..','XPs','functions','utilities')))
addpath(genpath(fullfile(pwd,'figUtilities')))
% Load path to useful directories and make sure they exist:
[dataDir, resultsDir, figuresDir, thesisDir] = initDirs();
% Load colors from the template:
[COLORS]=loadColors();

%% Load results from exampleXP:
% Error file:
fName   = fullfile(resultsDir, 'exampleXP','ERROR_in_Seconds.txt');
ERROR   = text2mat(fName);
fName   = fullfile(resultsDir, 'exampleXP','SNRs.txt');
SNRs    = importdata(fName);
nSNRs   = length(SNRs);

%% Figure preparation in matlab:
% ERROR in ms instead of seconds:
ERROR = ERROR * 1000;


% Prepare figure in matlab as usual:
hFig=figure(1);
set(hFig,'Position',[50 50 1000 500],'Color','w');
boxplot(ERROR, 'Colors', COLORS.lightblue)
ax = gca;
ax.XRuler.Exponent = 0;
colorBoxplot(gca);
% Define ticks and labels on x and y axis:
ylabel('Error [ms]')
xlabel('SNR [dB]')
set(gca,'XTick',1:nSNRs,'XTickLabel',SNRs)
ylim([0 50])
yTicks      =  0:10:50;
%yTickLabel  =  mat2str(yTicks*1000,0); % Strings without digits after the comma:
set(gca,'YTick',yTicks);%,'YTickLabel',{'0','10','20','30','40','50'})
% Add grid with no vertical line but horizontal lines:
gridxy([],5:5:45,'Color',COLORS.gray,'Linestyle',':')

%% Export Figure to insert in the Thesis:

fName=fullfile(figuresDir,'ExampleXP_boxplot.tex');
matlab2tikz('filename',fName,'figurehandle',hFig,'width','.8\textwidth','showInfo', false);
% The above function has a bug that adds a legend for the grid
% The 3 lines below remove it:
[C]=text2cell(fName);
C(find(contains(C,'\addlegendentry{data')))={''};
cell2text(C,fName);