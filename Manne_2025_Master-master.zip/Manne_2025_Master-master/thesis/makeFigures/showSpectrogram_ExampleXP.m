clear all, close all, clc
warning off
% Make sure we know what is on our Matlab path:
restoredefaultpath
% Add utilities functions from the XPs directory
addpath(genpath(fullfile(pwd,'..','..','XPs','functions','utilities')))
% Add signalModel functions from the XPs directory
addpath(genpath(fullfile(pwd,'..','..','XPs','functions','signalModel')))
addpath(genpath(fullfile(pwd,'figUtilities')))
% Load path to useful directories and make sure they exist:
[dataDir, resultsDir, figuresDir, thesisDir] = initDirs();
% Load colors from the template:
[COLORS]=loadColors();

%% Generate Signals to plot:
% Define parameters for signal generation:
fs                  = 1000;
nSecs               = 10;
ampPulse            = 1;
startSecPulse       = 0.5;
freqPulse           = 1;
ampLavare           = 2;
startSecLavare      = 3.5;
attenuationFactor   = 0.2;
sampDelay           = 500;

rng(123) % Seed for repeatability
SNR = 10;
% Generate simulated signal in first sensor:
[x, pulse, lavare]     = generate( fs, nSecs,...
    ampPulse,  startSecPulse, freqPulse,...
    ampLavare, startSecLavare);
L = length(x);

% Compute STFT of x
windowLength = 32;
[ anaWin, synWin ] = normWindow( windowLength );
X = caiSTFT( x, anaWin, windowLength/2);
X = 20*log10(abs(X((windowLength/2):end,:)));

[nBins, nFrames] = size(X);
% Two next lines to have centers of bin of the STFT
% Not relevant if you're just interested in the colormap example
xSpec = [0 L/fs]+[1 -1]*(windowLength/2/fs);
ySpec = [0 fs/2]+[1 -1]*(fs/2/nBins/2);


hFig = figure(1);
colormap(loadCmap()); % Load Template colormap
set(hFig,'Position',[50 50 1000 500],'Color','w');
imagesc(xSpec, ySpec, X,[-30 30])
xTick = linspace(0.01,9.99, 11);
yTick = linspace(1,fs/2-1, (fs/2)/100 + 1);
set(gca, 'XTick', xTick,'XTickLabel',0:1:10);
set(gca, 'YTick', yTick,'YTickLabel',500:-100:0);
xlabel('Time [s]')
ylabel('Frequency [Hz]')
hBar=colorbar('location','EastOutside');
fName=fullfile(figuresDir,'ExampleXP_spectrogram.tex');
matlab2tikz('filename',fName,'figurehandle',hFig,'width','.8\textwidth','showInfo', false,...
    'interpretTickLabelsAsTex',true,'parseStrings',false);
% Fix Colorbar
fixColorBar(fName,-30:5:30,'[dB]');
% Fix PNGs
fixPNGs(fName);



