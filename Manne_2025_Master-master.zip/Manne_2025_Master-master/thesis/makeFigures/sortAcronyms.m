% tiny bonus script.
% will sort the acronyms in myAcronyms.tex alphabetically
% they will then be sorted accordingly in the list when you compile the .pdf
% dont worry about it until the rest of the thesis is done

clear all, close all, clc
% Make sure we know what is on our Matlab path:
restoredefaultpath
% Add utilities functions from the XPs directory
addpath(genpath(fullfile(pwd,'..','..','XPs','functions','utilities')))
[dataDir, resultsDir, figuresDir, thesisDir] = initDirs();
fName = fullfile(thesisDir,'utilities','myAcronyms.tex');

%% Backup and read file:
copyfile(fName,strrep(fName,'.tex','.bak'));
fid             = fopen(fName,'r');
C               = textscan(fid,'%s','Delimiter','\n');
C               = C{1};
fclose(fid);

%% Rearrange acronyms:
beginRow        = find(contains(C,'\begin{acronym}'))+1;
endRow          = find(contains(C,'\end{acronym}'))-1;
acros           = C(beginRow:endRow);
acros           = cellfun(@(str) extractBetween(str,'[',']'), acros,'UniformOutput',false);
acros           = cellfun(@(str) str{1}, acros,'UniformOutput',false);
% find longest acronym on top to have nice list alignment:
[~,indLongest]  = max(cellfun('length', acros));
C{beginRow-1}   = ['\begin{acronym}[', acros{indLongest}, ']'];
% find alphabetical order
acros           = cellfun(@(str) upper(str), acros,'UniformOutput',false);
[ ~ , index]    = sort(acros);
index           = index -1;
C               = [ C(1:beginRow-1) ; C(beginRow + index) ; C(endRow+1:end) ];

%% Overwrite old file:
fid = fopen(fName,'w');
for indRow = 1:size(C,1)
    fprintf(fid,'%s\n',C{indRow});
end
fclose(fid);