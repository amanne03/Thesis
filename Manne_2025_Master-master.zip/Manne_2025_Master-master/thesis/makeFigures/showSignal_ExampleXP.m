clear all, close all, clc
warning off
% Make sure we know what is on our Matlab path:
restoredefaultpath
% Add utilities functions from the XPs directory
addpath(genpath(fullfile(pwd,'..','..','XPs','functions','utilities')))
% Add signalModel functions from the XPs directory
addpath(genpath(fullfile(pwd,'..','..','XPs','functions','signalModel')))
addpath(genpath(fullfile(pwd,'figUtilities')))
% Load path to useful directories and make sure they exist:
[dataDir, resultsDir, figuresDir, thesisDir] = initDirs();
% Load colors from the template:
[COLORS]=loadColors();

%% Generate Signals to plot:
% Define parameters for signal generation:
fs                  = 100;
nSecs               = 10;
ampPulse            = 1;
startSecPulse       = 0.5;
freqPulse           = 1;
ampLavare           = 2;
startSecLavare      = 3.5;
attenuationFactor   = 0.2;
sampDelay           = 500;

rng(123) % Seed for repeatability
SNR = 10;
% Generate simulated signal in first sensor:
[x, pulse, lavare]     = generate( fs, nSecs,...
    ampPulse,  startSecPulse, freqPulse,...
    ampLavare, startSecLavare);
% Below replace based on model of fluid propagation:
[y]     = attenuationFactor*circshift(x, sampDelay);
% Add uncorrelated gaussian noise to both signals:
% Requires Communications Toolbox: (we jsut use y * 0.1 in this figure example)
%[x_noisy, y_noisy]  = addNoise(x, y, SNR);  
y_noisy = y * 0.1;
x_noisy = x + y_noisy;

L = length(x);
xAxis = linspace(1,L/fs,L);
hFig = figure(1);
set(hFig,'Position',[50 50 1000 500],'Color','w');
for indSub =1:2
    subplot(2,1,indSub)
    set(gca,'box','on')
    %set(gca,'TickLabelInterpreter','latex');
    ylim([-4 4]);
    hold on
    xTick = linspace(1,L/fs, L/fs+1);
    set(gca, 'XTick',xTick, 'XTickLabel', 0:1:10)
    set(gca, 'YTickLabel',-4:2:4)
    if indSub ==1
        plot(xAxis,x, 'Color', COLORS.lightblue);
        plot(xAxis,y, 'Color', COLORS.orange);
        legendLabels = {'$\cleanSig{1}{\sampInd}$', '$\cleanSig{2}{\sampInd}$'};
    elseif indSub==2
        plot(xAxis, x_noisy, 'Color', COLORS.lightblue);
        plot(xAxis, y_noisy, 'Color', COLORS.orange);
        legendLabels = {'$\noisySig{1}{\sampInd}$', '$\noisySig{2}{\sampInd}$'};
        xlabel('Time [s]')
    end
    legend(legendLabels, 'Orientation','horizontal','Location','NorthWest')
    
    ylabel('Amplitude')
    yTicks = get(gca,'Ytick');
    gridxy(xTick(2:end-1),-3:3,'Color',COLORS.gray,'Linestyle',':')
end
%% Export Figure to insert in the Thesis:

fName=fullfile(figuresDir,'ExampleXP_signalplots.tex');
cleanfigure() % Usefull for figures with large number of points
matlab2tikz('filename',fName,'figurehandle',hFig,'width','.8\textwidth','showInfo', false, 'interpretTickLabelsAsTex',true,'parseStrings',false);
% The above function has a bug that adds a legend for the grid
% The 3 lines below remove it:
[C]=text2cell(fName);
C(find(contains(C,'\addlegendentry{data1')))={''};
C(find(contains(C,'dotted')))={'\addplot [color=mycolor1, dotted, forget plot]'};
cell2text(C,fName);
