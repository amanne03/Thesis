function [] = inflatePNG(pngFile, minPix)

if nargin<2 || isempty(minPix)
   minPix = 512;
end

img = imread(pngFile);

[rowFactor, colFactor] = deal(0);
[nRows, nCols, ~] = size(img);
if nRows<minPix
    rowFactor = ceil(minPix/nRows);
    index = repmat(1:nRows,[rowFactor 1]);
    index = index(:)';
    img = img(index, :, :);
end

if nCols<minPix
    colFactor = ceil(minPix/nCols);
    index = repmat(1:nCols,[colFactor 1]);
    index = index(:)';
    img = img(:, index, :);
end
if colFactor+rowFactor>0
    imwrite(img,pngFile)
end
end