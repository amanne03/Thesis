function [] = colorBoxplot(ax)
% Boxplot are a bit trickier than other figures to customize:
% orange stuff:
[COLORS]=loadColors();
boxplotProperties = {'Outliers','Median'};
for pp= 1:length(boxplotProperties)
    if strcmp(boxplotProperties{pp},'Outliers')
        prop = 'MarkerEdgeColor';
    else
        prop = 'Color';
    end
    set(findobj(ax, 'type', 'line', 'Tag', boxplotProperties{pp}), prop , COLORS.orange);
end
% gray stuff:
boxplotProperties = {'Upper Whisker','Lower Whisker','Upper Adjacent Value','Lower Adjacent Value'};
for pp= 1:length(boxplotProperties)
    if strcmp(boxplotProperties{pp},'Outliers')
        prop = 'MarkerEdgeColor';
    else
        prop = 'Color';
    end
    set(findobj(ax, 'type', 'line', 'Tag', boxplotProperties{pp}), prop , COLORS.gray);
end
end