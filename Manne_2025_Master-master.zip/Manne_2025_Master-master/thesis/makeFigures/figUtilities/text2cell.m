function [C]=text2cell(fName,CONVERT2NUM)
if nargin<2, CONVERT2NUM =0; end
    fid         = fopen(fName,'r');
    C           = textscan(fid,'%s','Delimiter','\n');
    fclose(fid);
    C           =C{1};
    if CONVERT2NUM
       for ii=1:length(C)
           C{ii}=str2num(C{ii});
       end
           C = cell2mat(C);
    end
end