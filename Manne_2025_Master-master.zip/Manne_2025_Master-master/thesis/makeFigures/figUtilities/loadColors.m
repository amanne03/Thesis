function [COLORS]=loadColors()

COLORS.black    = zeros(1,3);
COLORS.white    = ones(1,3);

% TEMPLATE COLORS
COLORS.darkblue = [ 35,  24, 89]./255;
COLORS.blue     = [  0,  25,125]./255;
COLORS.lightblue= [  0, 120,240]./255;
COLORS.orange   = [ 255,135,  0]./255;
COLORS.green    = [ 110,170, 35]./255;
COLORS.gray     = [ 100,100,100]./255;
COLORS.lightgray= [ 186,186,191]./255;


end


