function [CMAP]=loadCmap(nBins)
if nargin <1
    nBins = 257;
end

COLORS=loadColors();
C = [COLORS.lightblue  ; COLORS.lightgray ; COLORS.orange];
P = [0    ; 50        ; 100];

P           = round(P*(nBins-1)/100);
CMAP        = zeros(nBins,3);
nCols       = length(C);
for indCol  = 1:nCols-1
    for indRGB=1:3
        nCols = (P(indCol+1)-P(indCol))+1;
        CMAP(P(indCol)+1:P(indCol+1)+1,indRGB)=linspace(C(indCol,indRGB),C(indCol+1,indRGB),nCols);
    end
end



end