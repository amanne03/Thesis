function [] = fixPNGs(fName)

[C]=text2cell(fName);
nPNGs = length(find(contains(C,'.png')));
if nPNGs>0
    [fNameDir,fNameNoExt] = fileparts(fName);
    pngDir = fullfile(fNameDir, fNameNoExt);
    createDir(pngDir);
    for ind=1:nPNGs
        orig=[fNameNoExt,'-',num2str(ind),'.png'];
        Index = find(contains(C,orig));
        C{Index}=strrep(C{Index},orig,['figures','/',fNameNoExt,'/',orig]);
        movefile(fullfile(fNameDir,orig), pngDir);
        inflatePNG(fullfile(pngDir, orig));
    end
end
cell2text(C,fName);


end