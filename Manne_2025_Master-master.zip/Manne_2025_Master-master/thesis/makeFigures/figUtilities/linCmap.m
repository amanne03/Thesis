function [cMap]=linCmap(c1,c2,n)

cMap=zeros(n,3);
for ii=1:3
    cMap(:,ii)=linspace(c1(ii),c2(ii),n);
end

end