function cell2text(C,fName)

if size(C,3)>1, error('Does not support 3D arrays.'); end

if min(size(C))==1
    fID=fopen(fName,'w');
    if iscell(C)
        for kk=1:length(C)
            fprintf(fID, '%s\n', C{kk});
        end
    else
        for kk=1:length(C)
            fprintf(fID, '%s\n', num2str(C(kk)));
        end
    end
    fclose(fID);
else
    dlmwrite(fName,C,'delimiter','\t');
end
end