function []=printSpectrograms(Y,figDir,figName,dBlim,titles,specCmap)

if nargin<6
    specCmap = 'Red';
    if nargin < 5
        titles = [];
        if nargin < 4
            dBlim =[];
        end
    end
end
[nBins,nFrames,nSpecs]  = size(Y);
saveDir                 = fullfile('..',figDir);
nSecs                   = (nFrames+1)*0.016;
[CMAP]                  = loadCmap(specCmap,nBins);
subPos                  = zeros(nSpecs,4);

mL  = 0.03;     mR  = 0.06;
spH = 0.015;    spV = 0.08;
mT  = 0.04;     mB  = 0.07;

hFig=figure(1);
set(hFig,'Position',[10 50 1000 500],'Color','w');
for ind=1:nSpecs
    subaxis(ceil(nSpecs/2),2,ind,'SpacingHoriz',spH,'SpacingVert',spV,'MarginLeft',mL,'MarginRight',mR,'MarginBottom',mB,'MarginTop',mT);
    if isempty(dBlim)
        imagesc(Y(:,:,ind));
    else
        imagesc(Y(:,:,ind),dBlim);
    end
    colormap(flipud(CMAP));
    
    set(gca,'XTick', linspace(1,nFrames,nSecs*2+1));
    if ind>2
        xlabel('Time [s]')
        set(gca,'XTickLabel',0:0.5:nSecs);
    else
        set(gca,'XTickLabel',[] );
    end
    
    set(gca,'YTick', linspace(1,nBins,5));
    if mod(ind,2)
        ylabel('Frequency [kHz]')
        set(gca,'YTickLabel',8:-2:0 );
    else
        set(gca,'YTickLabel',[] );
    end
    subPos(ind,:) = get(gca,'Position');
    if ~isempty(titles)
        text(nFrames/2,-20,titles{ind},'HorizontalAlignment','center');
    end
    if ind==2 && ~isempty(dBlim)
        text(nFrames+11,-20,'dB','HorizontalAlignment','center');
    end
end
if ~isempty(dBlim)
    colorbar('Position', [subPos(nSpecs,1)+subPos(nSpecs,3)+spH subPos(nSpecs,2) subPos(nSpecs,3)/15 subPos(2,2)+subPos(2,4)-subPos(nSpecs,2)]);
end
fName=fullfile(saveDir,[figName,'.tex']);
matlab2tikz('filename',fName,'figurehandle',hFig,'width','.8\textwidth','showInfo', false,'showHiddenStrings',true,'imagesAsPng',true);

[C]=text2cell(fName);
for ind=1:nSpecs
    orig=[figName,'-',num2str(ind),'.png'];
    Index = find(contains(C,orig));
    C{Index}=strrep(C{Index},orig,fullfile(figDir,orig));
    cell2text(C,fName);
end


end