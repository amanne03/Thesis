function [] = fixColorBar(fName,yTick,yLabel,rotation)

if nargin < 4 || isempty(rotation)
    rotation = '-90';
else
    rotation = num2str(rotation);
end
yTick = mat2str(yTick(:)');
yTick = strjoin(yTick,',');
%yTick = [sprintf('%s,',yTick{1:end-1}),yTick{end}];

[C]=text2cell(fName);
Index = find(contains(C,'colorbar'));
C{Index} = ['colorbar, colorbar style={ytick={',yTick,'},ylabel=',yLabel,',ylabel style={rotate=',rotation,'}}'];
cell2text(C,fName);

end