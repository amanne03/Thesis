function [ y ] = caiISTFT( X, synWin, overlap, xLength, CUTFLAG, CAIFFT  )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

if nargin<6, CAIFFT=[]; end
if isempty(CAIFFT), CAIFFT=0; end

if nargin<5, CUTFLAG=[]; end
if isempty(CUTFLAG), CUTFLAG=0; end

if nargin<4, xLength=[]; end
if isempty(xLength)==0; TRUNCATE=0; else TRUNCATE=1; end

windowLength=length(synWin);
hop=windowLength-overlap;
nFrames=size(X,2);
matIdx = bsxfun(@plus, (1:windowLength).', (0:nFrames - 1) .* hop);
matSubIdx = matIdx;
if CUTFLAG
    %X=[flipud(X) ; conj(X(2:end-1,:))];
    X=[X ; flipud(conj(X(2:end-1,:)))];
end

if TRUNCATE
    y=zeros((size(X,2)-1)*hop+windowLength,1);
else
    y=zeros(xLength,1);
end

for indFrame=1:nFrames
    shat_ = real(ifft(X(:,indFrame), 'symmetric'));
    y(matSubIdx(:, indFrame)) = y(matSubIdx(:, indFrame)) + shat_.*synWin;
end
% Y=ifft(X).*repmat(synWin,[1, size(X,2)])*windowLength;
% y=zeros((size(Y,2)-1)*hop+windowLength,1);
% for ind=1:size(Y,2)
%    y((ind-1)*hop+1:(ind-1)*hop+windowLength)= y((ind-1)*hop+1:(ind-1)*hop+windowLength)+Y(:,ind);
% end
%
% if TRUNCATE
%    y=y(overlap+1:xLength+overlap);
% else
%    y=y(overlap+1:end);
% end
% y=real(y);
end

