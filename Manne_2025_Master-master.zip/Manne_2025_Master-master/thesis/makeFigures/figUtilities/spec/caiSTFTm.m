function [ X] = caiSTFTm( x, anaWin, overlap, CUTFLAG, CAIFFT )
%
if nargin<5, CAIFFT=[]; end
if isempty(CAIFFT), CAIFFT=0; end

if nargin<4, CUTFLAG=[]; end
if isempty(CUTFLAG), CUTFLAG=0; end

if nargin<3, overlap=[]; end
if isempty(overlap), overlap=length(anaWin)/2; end

nCh=size(x,2);
X=caiSTFT( x(:,1), anaWin, overlap, CUTFLAG, CAIFFT );

if nCh>1
    X=cat(3,X,zeros(size(X,1),size(X,2),nCh-1));
    for indCh=2:nCh
        X(:,:,indCh)=caiSTFT( x(:,indCh), anaWin, overlap, CUTFLAG, CAIFFT );
    end
end
end