function [ X] = caiSTFT( x, anaWin, overlap, CUTFLAG, CAIFFT )
%


if nargin<5, CAIFFT=[]; end
if isempty(CAIFFT), CAIFFT=0; end

if nargin<4, CUTFLAG=[]; end
if isempty(CUTFLAG), CUTFLAG=0; end

windowLength=length(anaWin);
[ frames ] = makeFrames( x, windowLength, overlap );
frames= frames.*repmat(anaWin,[1, size(frames,2)]);
if CAIFFT
    X=caiFFT(frames)/windowLength;
else
    X=fft(frames);%/windowLength;
end
if CUTFLAG
    %X=flipud(X(1:windowLength/2+1,:));
    X=X(1:windowLength/2+1,:);
end

end

function [ frames ] = makeFrames( x, windowLength, overlap )
%
frShift=windowLength-overlap;
% compute number of frames
nFrames = floor((length(x) - windowLength) / frShift) + 1;
matIdx = bsxfun(@plus, (1:windowLength).', (0:nFrames - 1) .* frShift);
frames = x(matIdx);
% x=x(:);
% hop=windowLength-overlap;
% nFrames = ceil((length(x)-overlap)/(windowLength-overlap))+1;
% frames=zeros(windowLength,nFrames);
% if numel(frames)>length(x)
%     x=[x ; zeros(numel(frames)-length(x),1)];
% end
% for indFrame=1:nFrames
%     frames(:,indFrame)=x((indFrame-1)*hop+1:(indFrame-1)*hop+windowLength);
% end
end