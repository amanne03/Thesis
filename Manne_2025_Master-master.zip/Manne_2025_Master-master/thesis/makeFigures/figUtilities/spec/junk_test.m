clear all, close all, clc

% General parameters
fs=16000;
windowLength=512;
nBins=windowLength/2+1;
overlap=256;
CUTFLAG=1;
[ anaWin, synWin ] = normWindow( windowLength);

y=randn(5*fs,1);
[ Y] = caiSTFTm( y, anaWin, overlap, CUTFLAG );
yy = caiISTFT( Y, synWin, overlap, size(y,1), CUTFLAG);
max(abs(y-yy))


z=ones(5*fs,1);
[ Z] = caiSTFTm( z, anaWin, overlap, CUTFLAG );
zz = caiISTFT( Z, synWin, overlap, size(y,1), CUTFLAG);
max(abs(z-zz))
