function [ x ] = caiIFFT( X )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

[N,nFrames]=size(X);
x=zeros(N,nFrames);

n = 0:N-1;
W = 2*pi*(0:N-1)/N;

for indFrame=1:nFrames
    x(:,indFrame) = (1/N * X(:,indFrame)' * exp(1j*n'*W))';
end
%x=real(x);

end

