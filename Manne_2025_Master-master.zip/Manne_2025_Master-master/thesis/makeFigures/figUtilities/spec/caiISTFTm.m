function [ y ] = caiISTFTm( X, synWin, overlap, xLength, CUTFLAG, CAIFFT  )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

if nargin<6, CAIFFT=[]; end
if isempty(CAIFFT), CAIFFT=0; end

if nargin<5, CUTFLAG=[]; end
if isempty(CUTFLAG), CUTFLAG=0; end

if nargin<4, xLength=[]; end
if isempty(xLength)==0; TRUNCATE=1; else TRUNCATE=0; end

windowLength=length(synWin);
hop=windowLength-overlap;

nCh=size(X,3);

[ y ] = caiISTFT( X(:,:,1), synWin, overlap, xLength, CUTFLAG, CAIFFT  );
if nCh>1
   y=[y , zeros(length(y),nCh-1)];
   for indCh=2:nCh
       [ y(:,indCh) ] = caiISTFTm( X(:,:,indCh), synWin, overlap, xLength, CUTFLAG, CAIFFT  );
   end
end


end

