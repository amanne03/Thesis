function [ anaWin, synWin ] = normWindow( windowLength, type)
% generate window which respects completness condition
if nargin<2, type='hanning'; end
normWin=window(str2func(type),windowLength,'periodic');
anaWin=sqrt(normWin);
if nargout>1
    synWin=sqrt(normWin);
end
end


