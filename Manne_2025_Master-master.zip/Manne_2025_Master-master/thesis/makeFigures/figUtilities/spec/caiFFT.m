function [ X ] = caiFFT( x )
%
[N,nFrames]=size(x);
X=zeros(N,nFrames);

m = 0:N-1;
W = 2*pi*(0:N-1)/N;

for indFrame=1:nFrames
X(:,indFrame)=(x(:,indFrame)' * exp(-1j*m'*W))';
end

end

