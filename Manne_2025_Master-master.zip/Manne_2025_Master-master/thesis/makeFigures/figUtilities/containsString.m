% ouput:
% isIndex: index of cell whose string contains pattern
% notIndex: index of cell whose string does NOT contain pattern

function [isIndex,notIndex]=containsString(C,pattern)

if iscell(pattern)==0
    index = strfind(C, pattern);
    isIndex = find(not(cellfun('isempty', index)));
    if nargout>1
        notIndex = find(cellfun('isempty', index));
    end
else
    nPatt=length(pattern);
    isIndex=cell(nPatt,1);
    for indPatt=1:nPatt
        index = strfind(C, pattern{indPatt});
        isIndex{indPatt}=find(not(cellfun('isempty', index)));
        %if nargout>1
        %    notIndex{indPatt} = find(cellfun('isempty', index));
        %end
    end
    isIndex=cell2mat(isIndex);
    notIndex=[1:length(C)]';
    [junk,iIs,iNot]=intersect(isIndex,notIndex);
    notIndex(iNot)=[];
    
    
end


end