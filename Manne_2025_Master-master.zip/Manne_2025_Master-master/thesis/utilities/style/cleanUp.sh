#!/bin/bash
# set variables
#cd /Users/benjamincauchi/Desktop/ICASSP_2015
MAINFILE=$TEXPAD_ROOTFILE_NO_EXT


rm $MAINFILE.aux
rm $MAINFILE.dvi
rm $MAINFILE.log
rm $MAINFILE.bbl
rm $MAINFILE.blg
rm $MAINFILE.ps
rm bu*.*
rm *.lof
rm *.lot
rm *.idx
rm *.toc
rm ./chapters/*.aux

#rm -f ./figures/*.pdf
# SHOW:
#if [ "$(uname)" == "Darwin" ]; then
#   open -a Preview $MAINFILE.pdf       
#elif [ "$(expr substr $(uname -s) 1 5)" == "Linux" ]; then
#   evince $MAINFILE.pdf
#fi


